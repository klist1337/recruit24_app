--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.2 (Debian 16.2-1.pgdg120+2)
-- Dumped by pg_dump version 16.2 (Debian 16.2-1.pgdg120+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE postgres;
--
-- Name: postgres; Type: DATABASE; Schema: -; Owner: domi
--

CREATE DATABASE postgres WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE postgres OWNER TO domi;

\connect postgres

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE postgres; Type: COMMENT; Schema: -; Owner: domi
--

COMMENT ON DATABASE postgres IS 'default administrative connection database';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: companydata; Type: TABLE; Schema: public; Owner: domi
--

CREATE TABLE public.companydata (
    employer character varying(40),
    job_title character varying(40),
    country_and_state character varying(4096),
    year_wages character varying(40),
    years_require_experience character varying(40),
    job_description character varying(4096),
    job_location character varying(4096),
    company_description character varying(4096),
    responsibilities character varying(4096),
    requirements_for_role character varying(4096),
    start_date character varying(40),
    posting_date character varying(40),
    _id integer NOT NULL,
    mytimestamp timestamp without time zone DEFAULT CURRENT_TIMESTAMP(6)
);


ALTER TABLE public.companydata OWNER TO domi;

--
-- Name: companydata__id_seq; Type: SEQUENCE; Schema: public; Owner: domi
--

CREATE SEQUENCE public.companydata__id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.companydata__id_seq OWNER TO domi;

--
-- Name: companydata__id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: domi
--

ALTER SEQUENCE public.companydata__id_seq OWNED BY public.companydata._id;


--
-- Name: companydata _id; Type: DEFAULT; Schema: public; Owner: domi
--

ALTER TABLE ONLY public.companydata ALTER COLUMN _id SET DEFAULT nextval('public.companydata__id_seq'::regclass);


--
-- Data for Name: companydata; Type: TABLE DATA; Schema: public; Owner: domi
--

COPY public.companydata (employer, job_title, country_and_state, year_wages, years_require_experience, job_description, job_location, company_description, responsibilities, requirements_for_role, start_date, posting_date, _id, mytimestamp) FROM stdin;
\.
COPY public.companydata (employer, job_title, country_and_state, year_wages, years_require_experience, job_description, job_location, company_description, responsibilities, requirements_for_role, start_date, posting_date, _id, mytimestamp) FROM '$$PATH$$/3350.dat';

--
-- Name: companydata__id_seq; Type: SEQUENCE SET; Schema: public; Owner: domi
--

SELECT pg_catalog.setval('public.companydata__id_seq', 324, true);


--
-- Name: companydata companydata_pkey; Type: CONSTRAINT; Schema: public; Owner: domi
--

ALTER TABLE ONLY public.companydata
    ADD CONSTRAINT companydata_pkey PRIMARY KEY (_id);


--
-- PostgreSQL database dump complete
--

